/* Renderização de listas a partir de data.js */
(function () {
  function badgeClass(level) {
    if (level === "facil" || level === "calmo") return "badge badge-ok";
    if (level === "dificil" || level === "intenso") return "badge badge-warn";
    return "badge";
  }

  function placeCard(place) {
    const labels = window.TOLEDO_DATA.levelLabel;
    return (
      '<a class="place-card" href="lugar.html?slug=' +
      encodeURIComponent(place.slug) +
      '">' +
      '<div class="place-thumb" role="img" aria-label="Ilustração de ' +
      place.name +
      '"></div>' +
      '<div class="place-body">' +
      '<p class="kicker" style="margin:0">' +
      place.kicker +
      "</p>" +
      "<h3>" +
      place.name +
      "</h3>" +
      "<p>" +
      place.short +
      "</p>" +
      '<p class="badges">' +
      '<span class="' +
      badgeClass(place.mobility.level) +
      '">' +
      labels[place.mobility.level] +
      "</span>" +
      '<span class="' +
      badgeClass(place.sensory.level) +
      '">' +
      labels[place.sensory.level] +
      "</span>" +
      "<span class=\"badge\">" +
      place.duration +
      "</span>" +
      "</p></div></a>"
    );
  }

  function renderPlacesList(selector, limit) {
    const el = document.querySelector(selector);
    if (!el || !window.TOLEDO_DATA) return;
    const list = limit
      ? window.TOLEDO_DATA.places.slice(0, limit)
      : window.TOLEDO_DATA.places;
    el.innerHTML = list.map(placeCard).join("");
  }

  function renderPlaceDetail() {
    const el = document.getElementById("place-detail");
    if (!el || !window.TOLEDO_DATA) return;
    const params = new URLSearchParams(location.search);
    const slug = params.get("slug");
    const place = window.TOLEDO_DATA.places.find((p) => p.slug === slug);
    const labels = window.TOLEDO_DATA.levelLabel;
    if (!place) {
      el.innerHTML =
        '<h1>Lugar não encontrado</h1><p><a href="lugares.html">Voltar aos lugares</a></p>';
      return;
    }
    document.title = place.name + " · Toledo Acessível";
    el.innerHTML =
      '<p><a class="btn btn-ghost" href="lugares.html">← Voltar aos lugares</a></p>' +
      '<header class="mt-2">' +
      '<p class="kicker">' +
      place.kicker +
      "</p>" +
      "<h1>" +
      place.name +
      "</h1>" +
      '<p class="lead">' +
      place.short +
      "</p>" +
      '<dl class="meta-grid">' +
      "<div><dt>Área</dt><dd>" +
      place.area +
      "</dd></div>" +
      "<div><dt>Tempo</dt><dd>" +
      place.duration +
      "</dd></div>" +
      "<div><dt>Custo</dt><dd>" +
      place.cost +
      "</dd></div>" +
      "<div><dt>Melhor hora</dt><dd>" +
      place.bestTime +
      "</dd></div>" +
      "</dl></header>" +
      '<div class="hero-photo mt-3" role="img" aria-label="Ilustração de ' +
      place.name +
      '"></div>' +
      '<div class="stack-gap mt-3">' +
      place.body.map((p) => "<p>" + p + "</p>").join("") +
      "</div>" +
      '<section class="detail-grid mt-3" aria-label="Acessibilidade do lugar">' +
      '<div class="panel"><h2>Deficiência física</h2>' +
      "<p><strong>" +
      labels[place.mobility.level] +
      "</strong></p><ul class=\"list-clean\">" +
      "<li>" +
      place.mobility.notes +
      "</li>" +
      "<li>Estacionamento: " +
      place.mobility.parking +
      "</li>" +
      "<li>Banheiros: " +
      place.mobility.restrooms +
      "</li>" +
      "<li>Piso: " +
      place.mobility.terrain +
      "</li>" +
      "<li>Pausa: " +
      place.mobility.rest +
      "</li></ul></div>" +
      '<div class="panel"><h2>Autismo e sensorial</h2>' +
      "<p><strong>" +
      labels[place.sensory.level] +
      "</strong></p><ul class=\"list-clean\">" +
      "<li>Som: " +
      place.sensory.noise +
      "</li>" +
      "<li>Luz: " +
      place.sensory.light +
      "</li>" +
      "<li>Gente: " +
      place.sensory.crowd +
      "</li>" +
      "<li>Cheiro: " +
      place.sensory.smell +
      "</li>" +
      "<li>" +
      place.sensory.tips +
      "</li></ul></div></section>" +
      '<section class="soft mt-3"><h2>Surdez e comunicação visual</h2>' +
      "<p>" +
      place.deaf.visual +
      "</p><p class=\"muted\">" +
      place.deaf.notes +
      "</p></section>" +
      '<p class="mt-3"><a class="btn btn-secondary" href="roteiro.html">Encaixar no roteiro de 3 dias</a></p>';
  }

  function renderRoteiro() {
    const story = document.getElementById("social-story");
    const days = document.getElementById("itinerary-days");
    if (!window.TOLEDO_DATA) return;
    if (story) {
      story.innerHTML = window.TOLEDO_DATA.socialStory
        .map(
          (item) =>
            '<li class="story-card"><p class="kicker" style="margin:0">Passo ' +
            item.step +
            "</p><h3>" +
            item.title +
            "</h3><p>" +
            item.text +
            "</p></li>"
        )
        .join("");
    }
    if (days) {
      days.innerHTML = window.TOLEDO_DATA.itinerary
        .map((day) => {
          const blocks = day.blocks
            .map((b) => {
              const title = b.placeSlug
                ? '<a href="lugar.html?slug=' +
                  encodeURIComponent(b.placeSlug) +
                  '">' +
                  b.title +
                  "</a>"
                : b.title;
              return (
                '<li class="day-block"><p class="day-time">' +
                b.time +
                "</p><div><h3>" +
                title +
                (b.rest
                  ? ' <span class="badge badge-ok" style="font-size:0.8rem;font-weight:500">Pausa</span>'
                  : "") +
                "</h3><p>" +
                b.detail +
                '</p><p class="muted" style="font-size:0.9rem">Sensorial: ' +
                b.sensory +
                "</p></div></li>"
              );
            })
            .join("");
          return (
            '<section class="section" aria-labelledby="' +
            day.id +
            '"><h2 id="' +
            day.id +
            '">' +
            day.title +
            "</h2><p>" +
            day.promise +
            '</p><p class="muted">' +
            day.energy +
            '</p><ol class="card-list mt-2" style="list-style:none;padding:0">' +
            blocks +
            "</ol></section>"
          );
        })
        .join("");
    }
  }

  function renderComida() {
    const el = document.getElementById("comida-list");
    if (!el || !window.TOLEDO_DATA) return;
    el.innerHTML = window.TOLEDO_DATA.gastronomy
      .map(
        (item) =>
          '<article class="panel"><h2>' +
          item.name +
          "</h2><p>" +
          item.text +
          '</p><p class="muted mt-1">Sensorial: ' +
          item.sensory +
          '</p><p class="muted">Acesso: ' +
          item.access +
          "</p></article>"
      )
      .join("");
  }

  document.addEventListener("DOMContentLoaded", () => {
    renderPlacesList("#home-places", 3);
    renderPlacesList("#all-places");
    renderPlaceDetail();
    renderRoteiro();
    renderComida();
  });
})();
