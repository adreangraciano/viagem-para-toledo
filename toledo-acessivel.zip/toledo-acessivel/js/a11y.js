/* Programas de acessibilidade integrados */
(function () {
  const STORAGE_KEY = "toledo-acessivel";

  const DEFAULT = {
    profile: "default",
    contrast: "default",
    font: "default",
    fontScale: 100,
    spacing: "normal",
    dyslexia: false,
    calm: false,
    reduceMotion: false,
    largeTargets: false,
    hideImages: false,
    readingRuler: false,
    underlineLinks: false,
    simplify: false,
    vlibras: true,
  };

  const PRESETS = {
    default: {
      label: "Padrão",
      summary: "Visual original do guia, com todos os programas disponíveis.",
    },
    autismo: {
      label: "Autismo",
      summary: "Modo calmo, sem movimento, rotina previsível e layout simplificado.",
      calm: true,
      reduceMotion: true,
      simplify: true,
      spacing: "relaxed",
    },
    surdez: {
      label: "Surdez",
      summary: "Libras, textos visuais e legendas. Nada depende só de som.",
      vlibras: true,
      underlineLinks: true,
    },
    dislexia: {
      label: "Dislexia",
      summary: "Fonte Lexend, espaçamento amplo e régua de leitura.",
      dyslexia: true,
      font: "lexend",
      spacing: "wide",
      readingRuler: true,
      reduceMotion: true,
    },
    "baixa-visao": {
      label: "Baixa visão",
      summary: "Alto contraste, texto grande e links sublinhados.",
      contrast: "high",
      font: "atkinson",
      fontScale: 140,
      underlineLinks: true,
      largeTargets: true,
      spacing: "relaxed",
    },
    motora: {
      label: "Deficiência física",
      summary: "Botões grandes, atalhos e paleta de comandos sem precisão fina.",
      largeTargets: true,
      fontScale: 115,
      spacing: "relaxed",
    },
  };

  let state = load();
  let speaking = false;

  function load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return { ...DEFAULT };
      return { ...DEFAULT, ...JSON.parse(raw) };
    } catch {
      return { ...DEFAULT };
    }
  }

  function save() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  function apply() {
    const el = document.documentElement;
    el.lang = "pt-BR";
    el.dataset.profile = state.profile;
    el.dataset.contrast = state.contrast;
    el.dataset.font = state.font;
    el.dataset.spacing = state.spacing;
    el.dataset.dyslexia = state.dyslexia ? "on" : "off";
    el.dataset.calm = state.calm ? "on" : "off";
    el.dataset.motion = state.reduceMotion ? "reduce" : "full";
    el.dataset.targets = state.largeTargets ? "large" : "default";
    el.dataset.images = state.hideImages ? "hide" : "show";
    el.dataset.ruler = state.readingRuler ? "on" : "off";
    el.dataset.underline = state.underlineLinks ? "on" : "off";
    el.dataset.simplify = state.simplify ? "on" : "off";
    el.style.setProperty("--a11y-scale", String(state.fontScale / 100));

    const ruler = document.getElementById("reading-ruler");
    if (ruler) ruler.hidden = !state.readingRuler;

    const live = document.getElementById("a11y-live");
    if (live && live.dataset.last !== undefined) {
      /* announcements handled by announce() */
    }

    syncUi();
    save();
  }

  function announce(message) {
    const live = document.getElementById("a11y-live");
    if (!live) return;
    live.textContent = "";
    setTimeout(() => {
      live.textContent = message;
    }, 50);
  }

  function setProfile(id) {
    const preset = PRESETS[id] || PRESETS.default;
    state = {
      ...DEFAULT,
      ...preset,
      profile: id,
      vlibras: true,
    };
    apply();
    announce("Perfil " + preset.label + " ativado. " + preset.summary);
  }

  function patch(partial) {
    state = { ...state, ...partial };
    apply();
  }

  function bumpFont(delta) {
    state.fontScale = Math.min(200, Math.max(100, state.fontScale + delta));
    apply();
    announce("Tamanho do texto " + state.fontScale + " por cento.");
  }

  function reset() {
    state = { ...DEFAULT };
    apply();
    announce("Acessibilidade restaurada ao padrão.");
  }

  function speakPage() {
    if (!window.speechSynthesis) {
      announce("Leitura em voz alta indisponível neste navegador.");
      return;
    }
    if (speaking) {
      window.speechSynthesis.cancel();
      speaking = false;
      announce("Leitura interrompida.");
      syncUi();
      return;
    }
    const main = document.getElementById("conteudo");
    const text = (main ? main.innerText : document.body.innerText)
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 4000);
    if (!text) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "pt-BR";
    u.rate = 0.92;
    const voices = window.speechSynthesis.getVoices();
    const voice =
      voices.find((v) => v.lang === "pt-BR") ||
      voices.find((v) => v.lang.startsWith("pt")) ||
      voices[0];
    if (voice) u.voice = voice;
    u.onend = () => {
      speaking = false;
      syncUi();
    };
    speaking = true;
    window.speechSynthesis.speak(u);
    announce("Lendo a página em voz alta.");
    syncUi();
  }

  function syncUi() {
    document.querySelectorAll("[data-profile]").forEach((btn) => {
      btn.setAttribute("aria-pressed", btn.dataset.profile === state.profile ? "true" : "false");
    });

    const map = {
      calm: "calm",
      reduceMotion: "reduceMotion",
      dyslexia: "dyslexia",
      readingRuler: "readingRuler",
      hideImages: "hideImages",
      largeTargets: "largeTargets",
      underlineLinks: "underlineLinks",
      simplify: "simplify",
      vlibras: "vlibras",
    };
    Object.keys(map).forEach((key) => {
      const input = document.querySelector('[data-toggle="' + key + '"]');
      if (input) input.checked = !!state[key];
    });

    const contrastBtn = document.getElementById("btn-contrast");
    if (contrastBtn) {
      contrastBtn.setAttribute("aria-pressed", state.contrast === "high" ? "true" : "false");
    }
    const speakBtn = document.getElementById("btn-speak");
    if (speakBtn) {
      speakBtn.setAttribute("aria-pressed", speaking ? "true" : "false");
      speakBtn.textContent = speaking ? "Parar" : "Ouvir";
    }
  }

  function loadVLibras() {
    if (!state.vlibras) return;
    if (document.getElementById("vlibras-plugin-script")) return;
    const root = document.createElement("div");
    root.setAttribute("vw", "");
    root.className = "enabled";
    root.innerHTML =
      '<div vw-access-button class="active"></div><div vw-plugin-wrapper><div class="vw-plugin-top-wrapper"></div></div>';
    document.body.appendChild(root);
    const script = document.createElement("script");
    script.id = "vlibras-plugin-script";
    script.src = "https://vlibras.gov.br/app/vlibras-plugin.js";
    script.async = true;
    script.onload = function () {
      try {
        if (window.VLibras) new window.VLibras.Widget("https://vlibras.gov.br/app");
      } catch (e) {
        /* opcional */
      }
    };
    document.body.appendChild(script);
  }

  function setupRuler() {
    const ruler = document.getElementById("reading-ruler");
    if (!ruler) return;
    window.addEventListener("mousemove", (e) => {
      if (!state.readingRuler) return;
      ruler.style.top = e.clientY - 20 + "px";
    });
    window.addEventListener("keydown", (e) => {
      if (!state.readingRuler) return;
      const top = parseFloat(ruler.style.top || "0");
      if (e.key === "ArrowDown") ruler.style.top = Math.min(window.innerHeight - 40, top + 28) + "px";
      if (e.key === "ArrowUp") ruler.style.top = Math.max(0, top - 28) + "px";
    });
  }

  function setupToolbar() {
    const toggle = document.getElementById("btn-a11y-toggle");
    const panel = document.getElementById("painel-a11y");
    if (toggle && panel) {
      toggle.addEventListener("click", () => {
        const open = panel.hidden;
        panel.hidden = !open;
        toggle.setAttribute("aria-expanded", open ? "true" : "false");
      });
    }

    document.getElementById("btn-font-down")?.addEventListener("click", () => bumpFont(-15));
    document.getElementById("btn-font-up")?.addEventListener("click", () => bumpFont(15));
    document.getElementById("btn-contrast")?.addEventListener("click", () => {
      patch({ contrast: state.contrast === "high" ? "default" : "high" });
      announce(state.contrast === "high" ? "Alto contraste ativado." : "Contraste padrão.");
    });
    document.getElementById("btn-speak")?.addEventListener("click", speakPage);
    document.getElementById("btn-commands")?.addEventListener("click", openCommands);
    document.getElementById("btn-reset")?.addEventListener("click", reset);

    document.querySelectorAll("[data-profile]").forEach((btn) => {
      btn.addEventListener("click", () => setProfile(btn.dataset.profile));
    });

    document.querySelectorAll("[data-toggle]").forEach((input) => {
      input.addEventListener("change", () => {
        const key = input.dataset.toggle;
        const value = input.checked;
        const extra = {};
        if (key === "dyslexia" && value) {
          extra.font = "lexend";
          extra.spacing = "wide";
        }
        if (key === "dyslexia" && !value) {
          extra.font = "default";
          extra.spacing = "normal";
        }
        if (key === "calm" && value) extra.reduceMotion = true;
        patch({ [key]: value, ...extra });
      });
    });
  }

  function setupMenu() {
    const btn = document.getElementById("menu-toggle");
    const nav = document.getElementById("menu-movel");
    if (!btn || !nav) return;
    btn.addEventListener("click", () => {
      const open = nav.hidden;
      nav.hidden = !open;
      btn.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  function setupCommands() {
    const backdrop = document.getElementById("cmd-backdrop");
    const input = document.getElementById("cmd-input");
    if (!backdrop || !input) return;

    window.addEventListener("keydown", (e) => {
      const isPalette =
        (e.ctrlKey || e.metaKey) &&
        (e.key.toLowerCase() === "k" || (e.shiftKey && e.key.toLowerCase() === "p"));
      if (isPalette) {
        e.preventDefault();
        if (backdrop.hidden) openCommands();
        else closeCommands();
      }
      if (e.key === "Escape" && !backdrop.hidden) closeCommands();
    });

    backdrop.addEventListener("click", (e) => {
      if (e.target === backdrop) closeCommands();
    });

    input.addEventListener("input", () => filterCommands(input.value));
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        const first = document.querySelector(".cmd-item:not([hidden])");
        first?.click();
      }
    });

    document.querySelectorAll(".cmd-item").forEach((item) => {
      item.addEventListener("click", () => {
        const action = item.dataset.action;
        runAction(action, item.dataset.value);
        closeCommands();
      });
    });
  }

  function openCommands() {
    const backdrop = document.getElementById("cmd-backdrop");
    const input = document.getElementById("cmd-input");
    if (!backdrop) return;
    backdrop.hidden = false;
    filterCommands("");
    setTimeout(() => input?.focus(), 30);
  }

  function closeCommands() {
    const backdrop = document.getElementById("cmd-backdrop");
    if (backdrop) backdrop.hidden = true;
  }

  function filterCommands(query) {
    const q = query.trim().toLowerCase();
    document.querySelectorAll(".cmd-item").forEach((item) => {
      const text = item.textContent.toLowerCase();
      item.hidden = q && !text.includes(q);
    });
  }

  function runAction(action, value) {
    switch (action) {
      case "profile":
        setProfile(value);
        break;
      case "font-up":
        bumpFont(15);
        break;
      case "font-down":
        bumpFont(-15);
        break;
      case "contrast":
        patch({ contrast: state.contrast === "high" ? "default" : "high" });
        break;
      case "speak":
        speakPage();
        break;
      case "ruler":
        patch({ readingRuler: !state.readingRuler });
        break;
      case "images":
        patch({ hideImages: !state.hideImages });
        break;
      case "reset":
        reset();
        break;
      case "nav":
        if (value) window.location.href = value;
        break;
      default:
        break;
    }
  }

  function markCurrentNav() {
    const path = location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll(".nav-link").forEach((a) => {
      const href = a.getAttribute("href") || "";
      const file = href.split("/").pop();
      if (file === path || (path === "" && file === "index.html")) {
        a.setAttribute("aria-current", "page");
      } else {
        a.removeAttribute("aria-current");
      }
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches && !state.reduceMotion) {
      state.reduceMotion = true;
    }
    apply();
    setupToolbar();
    setupMenu();
    setupCommands();
    setupRuler();
    loadVLibras();
    markCurrentNav();
    if (window.speechSynthesis) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.addEventListener("voiceschanged", () => {
        window.speechSynthesis.getVoices();
      });
    }
  });

  window.ToledoA11y = { setProfile, patch, bumpFont, reset, speakPage, PRESETS };
})();
