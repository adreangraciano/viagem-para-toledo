/* Dados do guia Toledo Acessível */
window.TOLEDO_DATA = {
  places: [
    {
      slug: "lago-diva-paim-barth",
      name: "Lago e Parque Ecológico Diva Paim Barth",
      kicker: "Cartão-postal",
      short:
        "O lago urbano de Toledo, com pista de caminhada, sombra e quiosques. Ponto central para começar a viagem com calma.",
      body: [
        "O Parque Ecológico Diva Paim Barth fica na região central. O lago é o cartão-postal da cidade e um dos maiores lagos artificiais em perímetro urbano do Brasil.",
        "Há pista de caminhada, bancos, árvores e áreas de piquenique. No fim de semana o movimento aumenta. Em manhãs de dia útil o parque costuma ficar mais silencioso.",
        "A cidade já foi reconhecida entre as mais arborizadas do país. Este parque explica esse título: a água e as árvores entram no cotidiano, não ficam só no mapa.",
      ],
      area: "Centro",
      duration: "45 a 90 minutos",
      cost: "Entrada livre",
      bestTime: "Manhã de terça a quinta, ou fim de tarde em dia ameno",
      mobility: {
        level: "facil",
        notes:
          "A orla tem trechos pavimentados e contínuos. O percurso pode ser feito em cadeira de rodas com acompanhante, com algumas rampas suaves.",
        parking: "Estacionamento nas vias ao redor. Procure vagas reservadas perto das entradas.",
        restrooms: "Banheiros no entorno do parque e em estabelecimentos próximos.",
        terrain: "Piso misto: concreto, pedra e trechos de terra batida nas áreas internas.",
        rest: "Bancos frequentes à sombra. Bom lugar para pausa sensorial.",
      },
      sensory: {
        level: "calmo",
        noise: "Pássaros, conversas e, em eventos, som de palco. Sem evento, o ruído é baixo.",
        light: "Sol aberto no lago. Leve chapéu e óculos. A sombra das árvores é densa nas laterais.",
        crowd: "Moderado no fim de semana. Mais vazio em manhãs de semana.",
        smell: "Grama molhada, água parada em dias quentes. Pouco intenso.",
        tips: "Se a luz da água incomodar, caminhe pelo lado arborizado, de costas para o reflexo.",
      },
      deaf: {
        visual: "O parque se lê pelo olhar: água, caminho, bancos, placas. Não há informação só em áudio.",
        notes: "Leve o celular com o site aberto. O widget de Libras traduz os textos desta página.",
      },
    },
    {
      slug: "parque-dos-pioneiros",
      name: "Parque dos Pioneiros",
      kicker: "Lazer em família",
      short:
        "Parque com lago, ciclovia, academia ao ar livre e espaço para descanso. Ao lado fica o Parque Temático das Águas.",
      body: [
        "Inaugurado em 1996 em homenagem às famílias pioneiras. Tem lago, ciclovia, academia e a Academia da Terceira Idade.",
        "É um ponto de encontro familiar, sobretudo no verão. O ritmo é de cidade do interior: gente caminhando, crianças e grupos sentados na grama.",
        "Quem prefere menos estímulo pode usar a ciclovia em horário cedo e evitar o anexo aquático no mesmo dia.",
      ],
      area: "Zona de parques",
      duration: "1 a 2 horas",
      cost: "Entrada livre no parque",
      bestTime: "Manhã cedo, antes das 10h",
      mobility: {
        level: "parcial",
        notes:
          "Ciclovia e trechos planos ajudam. Grama e desníveis aparecem fora do caminho principal. A academia ao ar livre não é totalmente adaptada.",
        parking: "Estacionamento no parque.",
        restrooms: "Banheiros no complexo, inclusive no parque aquático anexo.",
        terrain: "Concreto na ciclovia, grama e terra nas laterais.",
        rest: "Bancos e sombra. Academia da Terceira Idade para pausa ativa.",
      },
      sensory: {
        level: "moderado",
        noise: "Vozes, bicicletas e, no verão, gritos do parque aquático ao lado.",
        light: "Sol pleno nas áreas abertas.",
        crowd: "Alto no fim de semana quente. Mais calmo em dias frios.",
        smell: "Grama, cloro se o parque aquático estiver aberto.",
        tips: "Fones com cancelamento de ruído ajudam se o parque aquático estiver cheio.",
      },
      deaf: {
        visual: "Sinalização de caminhos e equipamentos visíveis. Atividades são sobretudo visuais e físicas.",
        notes: "Combine o encontro em um ponto fixo, como o monumento aos pioneiros.",
      },
    },
    {
      slug: "parque-tematico-das-aguas",
      name: "Parque Temático das Águas",
      kicker: "Água livre",
      short:
        "Piscinas, toboágua e rio lento com entrada gratuita. Único do gênero no município. Exige exame médico.",
      body: [
        "Anexo ao Parque dos Pioneiros, junto ao rio Toledo. Inaugurado em 2009, reformado após a pandemia.",
        "Tem piscina infantil e adulta, tobobóia, toboágua, rio lento, quiosques, vestiários e banheiros. A entrada é gratuita mediante exame médico.",
        "É um dos poucos parques aquáticos públicos desse porte com entrada livre no país. O estímulo sensorial é alto: água, gritos, sol e cheiro de cloro.",
      ],
      area: "Anexo ao Parque dos Pioneiros",
      duration: "2 a 3 horas",
      cost: "Gratuito, com exame médico",
      bestTime: "Dias de semana no verão, logo na abertura",
      mobility: {
        level: "parcial",
        notes:
          "Há piso molhado, desníveis e escadas nos brinquedos. Quem usa cadeira de rodas pode circular em trechos secos, mas os toboáguas não são adaptados. Confirme com a administração cadeiras anfíbias ou rampas de tanque.",
        parking: "Mesmo estacionamento do Parque dos Pioneiros.",
        restrooms: "Vestiários e banheiros no complexo. Pergunte o boxe acessível na portaria.",
        terrain: "Piso molhado, cerâmica e concreto. Risco de escorregar.",
        rest: "Quiosques e sombreiros. Leve toalha extra para pausa seca.",
      },
      sensory: {
        level: "intenso",
        noise: "Alto. Crianças, água e música ambiente.",
        light: "Sol forte, reflexo na água. Óculos escuros ajudam.",
        crowd: "Muito cheio em feriados quentes.",
        smell: "Cloro nítido.",
        tips: "Evite se barulho ou toque de água forem gatilhos. Prefira outro dia no lago calmo.",
      },
      deaf: {
        visual:
          "Regras costumam estar em placas. Leve o exame médico impresso. Combine sinais visuais com o grupo dentro da água.",
        notes: "Não dependa de apito. Combine um ponto de reencontro em terra.",
      },
    },
    {
      slug: "aquario-romulo-martinelli",
      name: "Aquário Municipal Rômulo Martinelli",
      kicker: "Água parada, luz baixa",
      short:
        "Nove tanques de água doce e um recorte marinho, em prédio reaproveitado da antiga concha acústica.",
      body: [
        "O aquário foi inaugurado em 8 de dezembro de 2007 a partir da Concha Acústica Bonifácio Dewes.",
        "São nove tanques de água doce, organizados por porte, hábito e espécie, e um aquário marinho. Há peixes das bacias do Paraná, do Iguaçu e do Amazonas.",
        "O ambiente é fechado, fresco e relativamente escuro. Para muita gente autista ou com baixa visão, a luz baixa pede tempo de adaptação. Para quem busca silêncio, é um dos melhores recintos da cidade.",
      ],
      area: "Junto aos parques centrais",
      duration: "30 a 50 minutos",
      cost: "Consulte a tarifa atual na portaria",
      bestTime: "Meio da manhã, longe de grupos escolares",
      mobility: {
        level: "parcial",
        notes:
          "Espaço compacto, cerca de 410 m². Corredores podem ser estreitos. Pergunte na entrada sobre degraus e rampa.",
        parking: "Nas ruas e no entorno do parque.",
        restrooms: "No complexo do parque.",
        terrain: "Piso interno liso, possível reflexo molhado.",
        rest: "Pouco assento interno. Planeje pausa no parque ao sair.",
      },
      sensory: {
        level: "calmo",
        noise: "Baixo, com zumbido de bombas d'água.",
        light:
          "Baixa, com focos nos tanques. Pode cansar quem tem baixa visão. Use a lanterna do celular só se permitido.",
        crowd: "Sobe com escolas. Fora disso, calmo.",
        smell: "Água e umidade, leve.",
        tips: "Entre, pare 30 segundos para os olhos se ajustarem, depois caminhe devagar.",
      },
      deaf: {
        visual:
          "A visita é visual por natureza. Placas identificam espécies. Peça legendas ou texto se houver mediador.",
        notes: "O texto deste site descreve cada tanque em linguagem simples para leitura no celular.",
      },
    },
    {
      slug: "teatro-municipal",
      name: "Teatro Municipal de Toledo",
      kicker: "Palco do oeste",
      short:
        "Um dos maiores teatros do interior paranaense, com mais de mil lugares e acústica elogiada.",
      body: [
        "O Teatro Municipal é referência cultural da cidade. A platéia tem 1.021 lugares e está entre as maiores do interior do Paraná.",
        "Além de espetáculos, recebe exposições e lançamentos de livros. Fica no centro, o que facilita combinar com a praça e a catedral.",
        "Para quem tem autismo, a sala escura e o aplauso súbito podem ser difíceis. Chegue cedo, escolha poltrona de corredor e combine um plano de saída.",
      ],
      area: "Centro",
      duration: "Duração do espetáculo, em geral 1h30 a 2h",
      cost: "Varia conforme a programação",
      bestTime: "Sessões mais cedo. Evite camarote se preferir saída rápida",
      mobility: {
        level: "facil",
        notes:
          "Teatro moderno, com corredores largos. Solicite poltrona acessível e espaço para cadeira de rodas na bilheteria. Há elevador em parte da circulação — confirme no dia.",
        parking: "Ruas do centro e estacionamentos privados.",
        restrooms: "Banheiros no foyer. Pergunte o sanitário acessível.",
        terrain: "Piso interno regular. Degraus na platéia convencional.",
        rest: "Foyer para pausa antes do espetáculo.",
      },
      sensory: {
        level: "moderado",
        noise: "Silêncio pedido na platéia, depois música e aplausos. O volume pode ser alto.",
        light: "Escuro na sala, holofotes no palco. Evite primeira fila se a luz estroboscópica incomodar.",
        crowd: "Filas na entrada e no intervalo.",
        smell: "Neutro, com perfume de foyer.",
        tips: "Fones de proteção e um cartão de “preciso sair” ajudam. Poltrona de corredor reduz o aperto.",
      },
      deaf: {
        visual:
          "Peça sessão com interpretação em Libras ou legendas. Nem toda peça tem. Na dúvida, escolha espetáculo visual ou exposição no foyer.",
        notes: "Ligue à frente e pergunte se haverá intérprete. Leve o VLibras no intervalo para ler o programa.",
      },
    },
    {
      slug: "catedral-cristo-rei",
      name: "Catedral Cristo Rei",
      kicker: "Centro silencioso",
      short:
        "Igreja matriz de Toledo, com vitrais e nave ampla. Bom refúgio de sombra, silêncio e ar-condicionado.",
      body: [
        "A Catedral Cristo Rei marca o centro da cidade. A arquitetura moderna, os vitrais e a nave alta criam um ambiente recolhido.",
        "Há missas regulares. Fora dos horários de celebração, o espaço costuma estar mais vazio e silencioso — útil como pausa sensorial no roteiro.",
        "Respeite o culto em andamento. Quem não quiser participar pode permanecer no adro ou voltar em outro horário.",
      ],
      area: "Centro",
      duration: "20 a 40 minutos",
      cost: "Entrada livre. Respeite a liturgia",
      bestTime: "Entre missas, no meio da manhã",
      mobility: {
        level: "parcial",
        notes:
          "O adro é amplo e plano. Confirme rampa na entrada principal. Interior com bancos fixos; deixe a cadeira de rodas no corredor lateral.",
        parking: "Ruas do centro.",
        restrooms: "Em geral há sanitário na secretaria paroquial. Confirme na portaria.",
        terrain: "Pedra e piso interno liso.",
        rest: "Bancos na nave e no adro sombreado.",
      },
      sensory: {
        level: "calmo",
        noise: "Muito baixo fora da missa. Órgão e canto durante a celebração.",
        light: "Vitrais projetam cor. Pode ser intenso ao meio-dia.",
        crowd: "Alto só na missa de domingo.",
        smell: "Incenso em algumas celebrações.",
        tips: "Se incenso for gatilho, visite em horário sem missa.",
      },
      deaf: {
        visual:
          "A arquitetura e os vitrais se bastam. Missas raramente têm intérprete de Libras — pergunte à paróquia.",
        notes: "Textos de oração podem ser acompanhados em folheto impresso.",
      },
    },
    {
      slug: "museu-willy-barth",
      name: "Museu Histórico Willy Barth",
      kicker: "Memória da cidade",
      short:
        "Acervo da fundação de Toledo, jornais, mapas e entrevistas com pioneiros. Visita curta e guiada pelo olhar.",
      body: [
        "Criado em 1976 e nomeado em honra a Willy Barth, figura central da colonização da região.",
        "Há exposições permanentes, temporárias e itinerantes, além de arquivo de jornais, revistas, mapas e um setor de imagem e som.",
        "A visita é boa para entender por que Toledo cresceu com a suinocultura, as cooperativas e as famílias do norte e do Rio Grande do Sul.",
      ],
      area: "Centro",
      duration: "40 a 70 minutos",
      cost: "Consulte a entrada atual",
      bestTime: "Início da tarde em dia de semana",
      mobility: {
        level: "parcial",
        notes:
          "Museus de prédio antigo podem ter desnível. Escreva ou ligue antes e pergunte rampa, elevador e cadeira de rodas de empréstimo.",
        parking: "Centro.",
        restrooms: "No prédio. Confirme acessível.",
        terrain: "Piso interno. Possíveis soleiras.",
        rest: "Bancos nas salas, em geral poucos. Não force a visita.",
      },
      sensory: {
        level: "calmo",
        noise: "Baixo, vozes de mediadores.",
        light: "Luz de exposição, às vezes pontual.",
        crowd: "Baixo, salvo grupos escolares.",
        smell: "Papel, madeira, poeira leve de acervo.",
        tips: "Peça um roteiro curto de 20 minutos se a atenção for limitada.",
      },
      deaf: {
        visual: "Acervo é objeto, foto e texto. Peça material escrito. Mediação em Libras não é garantida.",
        notes: "Fotografe as legendas (se permitido) para ler com calma depois.",
      },
    },
    {
      slug: "rota-das-lavandas",
      name: "Rota Turística de Lavanda",
      kicker: "Campo agendado",
      short:
        "Visita rural a campos de lavanda no entorno de Toledo. Só com agendamento. Cheiro forte e sol aberto.",
      body: [
        "A rota de lavanda é o recorte mais novo do turismo rural no oeste do Paraná. As propriedades são privadas.",
        "A visita depende de marcação prévia e tem custo. A florada muda com a estação — confirme se o campo está aberto.",
        "O deslocamento é de carro. Combine transporte acessível com antecedência. O piso é de terra e pedra de fazenda.",
      ],
      area: "Zona rural, com agendamento",
      duration: "2 a 3 horas, incluindo deslocamento",
      cost: "Pago, sob consulta",
      bestTime: "Manhã em dia seco, na florada",
      mobility: {
        level: "dificil",
        notes:
          "Terreno irregular, terra, possível lama. Cadeira de rodas manual terá dificuldade. Veículo adaptado chega até a sede; o campo em si é limitado. Pergunte visita só na varanda ou no café.",
        parking: "No sítio, em piso de terra.",
        restrooms: "Banheiro da propriedade. Acessível não é garantido.",
        terrain: "Terra vermelha, grama, desnível.",
        rest: "Varanda e café, quando houver.",
      },
      sensory: {
        level: "moderado",
        noise: "Campo silencioso, vento e abelhas.",
        light: "Sol pleno, sem sombra no meio do canteiro.",
        crowd: "Controlado pelo agendamento. Raramente lotado.",
        smell: "Lavanda muito intensa. Pode ser gatilho para hipersensibilidade olfativa.",
        tips: "Se cheiro forte incomoda, fique na borda do campo ou escolha outro passeio.",
      },
      deaf: {
        visual: "Paisagem aberta. Combine a visita por mensagem de texto com o produtor.",
        notes: "Leve perguntas escritas sobre a plantação. Fotos substituem bem o guia falado.",
      },
    },
  ],
  levelLabel: {
    facil: "Acesso mais fácil",
    parcial: "Acesso parcial",
    dificil: "Acesso difícil",
    calmo: "Sensorial calmo",
    moderado: "Sensorial moderado",
    intenso: "Sensorial intenso",
  },
  itinerary: [
    {
      id: "dia-1",
      title: "Dia 1 · Chegada e o lago",
      promise: "Um dia curto, ao ar livre, para conhecer o centro sem pressa.",
      energy: "Baixa. Bom para quem chegou de viagem e precisa de previsibilidade.",
      blocks: [
        {
          time: "9h00",
          title: "Café no centro",
          detail:
            "Escolha uma padaria na área central. Peça mesa de canto. O objetivo é só desacelerar depois da estrada.",
          sensory: "Cheiro de pão, conversas. Volume baixo a médio.",
          rest: false,
        },
        {
          time: "10h00",
          title: "Lago Diva Paim Barth",
          detail:
            "Caminhe no máximo 40 minutos na orla pavimentada. Sente-se quando quiser. Não há meta de voltas.",
          placeSlug: "lago-diva-paim-barth",
          sensory: "Calmo. Sol no espelho d'água. Use chapéu.",
          rest: false,
        },
        {
          time: "11h00",
          title: "Pausa obrigatória",
          detail:
            "Água, banheiro e 15 minutos sentado à sombra. Se estiver cansado, encerre a manhã aqui.",
          sensory: "Silêncio se você escolher um banco afastado da pista.",
          rest: true,
        },
        {
          time: "15h00",
          title: "Catedral Cristo Rei",
          detail:
            "Visita curta, fora do horário de missa. Entrou, olhou os vitrais, saiu. Vinte minutos bastam.",
          placeSlug: "catedral-cristo-rei",
          sensory: "Silêncio, sombra, possível incenso.",
          rest: false,
        },
        {
          time: "19h00",
          title: "Jantar perto do hotel",
          detail:
            "Evite deslocamento longo no primeiro dia. Cardápio escrito. Mesa encostada na parede.",
          sensory: "Moderado. Peça para baixar música se estiver alta.",
          rest: true,
        },
      ],
    },
    {
      id: "dia-2",
      title: "Dia 2 · Cultura em dose curta",
      promise: "Museu, aquário e, se houver energia, um espetáculo com poltrona de corredor.",
      energy: "Média. Dois recintos fechados e uma pausa longa no meio.",
      blocks: [
        {
          time: "9h30",
          title: "Museu Histórico Willy Barth",
          detail: "Peça um recorte de 40 minutos. Fotos, mapas e a história da colonização bastam.",
          placeSlug: "museu-willy-barth",
          sensory: "Calmo, luz de sala.",
          rest: false,
        },
        {
          time: "11h00",
          title: "Aquário Rômulo Martinelli",
          detail:
            "Ambiente escuro. Pare na entrada até os olhos se acostumarem. Depois rode os tanques sem pressa.",
          placeSlug: "aquario-romulo-martinelli",
          sensory: "Luz baixa, zumbido de filtro, cheiro úmido leve.",
          rest: false,
        },
        {
          time: "12h30",
          title: "Almoço e descanso",
          detail: "Volte ao hotel ou fique no parque. Duas horas livres. Sem compras obrigatórias.",
          sensory: "Você escolhe. Este bloco existe para recuperar o sistema sensorial.",
          rest: true,
        },
        {
          time: "20h00",
          title: "Teatro Municipal (opcional)",
          detail:
            "Só se houver sessão e disposição. Poltrona de corredor, plano de saída, fones de proteção na bolsa.",
          placeSlug: "teatro-municipal",
          sensory: "Escuro, aplauso, volume alto possível.",
          rest: false,
        },
      ],
    },
    {
      id: "dia-3",
      title: "Dia 3 · Escolha um ritmo",
      promise: "Ou parque com água e gente, ou campo de lavanda agendado. Não faça os dois.",
      energy: "Você escolhe: intenso (água) ou moderado (campo).",
      blocks: [
        {
          time: "Manhã A",
          title: "Opção calma: Parque dos Pioneiros",
          detail: "Ciclovia, banco, academia da terceira idade. Sem entrar na água.",
          placeSlug: "parque-dos-pioneiros",
          sensory: "Moderado ao ar livre.",
          rest: false,
        },
        {
          time: "Manhã B",
          title: "Opção intensa: Parque das Águas",
          detail: "Leve exame médico, toalha extra e um código de saída com o grupo.",
          placeSlug: "parque-tematico-das-aguas",
          sensory: "Intenso: cloro, gritos, sol, piso molhado.",
          rest: false,
        },
        {
          time: "Tarde",
          title: "Opção rural: lavandas",
          detail:
            "Só com hora marcada. Estrada de terra. Cheiro forte. Bom para quem gosta de campo e foto.",
          placeSlug: "rota-das-lavandas",
          sensory: "Sol, abelhas, aroma intenso de lavanda.",
          rest: false,
        },
        {
          time: "Fim do dia",
          title: "Encerramento previsível",
          detail: "Mesmo restaurante do dia 1, se gostou. Rotina igual reduz cansaço de decisão.",
          sensory: "Conhecido. Isso é proposital.",
          rest: true,
        },
      ],
    },
  ],
  socialStory: [
    {
      step: "1",
      title: "Antes de sair",
      text: "Vamos olhar o roteiro juntos. Sabemos o nome do lugar, quanto tempo dura e onde fica o banheiro.",
    },
    {
      step: "2",
      title: "No caminho",
      text: "O carro ou ônibus pode fazer barulho. Fones e um objeto conhecido ajudam. A viagem tem começo, meio e fim.",
    },
    {
      step: "3",
      title: "Na chegada",
      text: "Primeiro procuramos um banco. Depois olhamos o espaço. Ninguém é obrigado a entrar na hora.",
    },
    {
      step: "4",
      title: "A visita",
      text: "Podemos sair quando quisermos. Sair não é falha. É parte do plano.",
    },
    {
      step: "5",
      title: "A pausa",
      text: "Água, banheiro, sombra. Só então decidimos se há energia para o próximo bloco.",
    },
    {
      step: "6",
      title: "O fim do dia",
      text: "Voltamos ao hotel. O dia seguinte só começa no dia seguinte.",
    },
  ],
  gastronomy: [
    {
      name: "Porco no rolete",
      text: "Prato-símbolo de Toledo. O suíno gira inteiro em espeto com manivela, por horas, até a casca dourar. A Festa Nacional acontece no Clube Caça e Pesca, em setembro, e nasceu nos anos 1970.",
      sensory: "Cheiro forte de carne na brasa, fumaça, fila e som de festa. Intensidade alta.",
      access:
        "O clube tem áreas planas, mas o evento é cheio. Chegue cedo. Há pouco controle de filas acessíveis — peça apoio na portaria.",
    },
    {
      name: "Cozinha de cooperativa e interior",
      text: "Além da festa, a cidade come bem o ano todo: churrasco, massas da imigração, peixe de rio, café colonial e padarias de centro. Restaurantes no entorno do lago e do shopping concentram opções.",
      sensory: "Restaurantes de centro são previsíveis. Peça mesa de canto e cardápio escrito.",
      access:
        "Ligue antes e pergunte rampa, banheiro acessível e cadeira de bebê. Muitos salões de calçada têm um degrau.",
    },
  ],
};
