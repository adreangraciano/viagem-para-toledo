# Toledo Acessível

Guia de viagem para **Toledo, Paraná (Brasil)** com programas de acessibilidade integrados no código.

Site estático em HTML, CSS e JavaScript — abre no navegador e sobe fácil no GitHub Pages.

## Como abrir no Visual Studio Code

1. Baixe ou clone esta pasta `toledo-acessivel`
2. No VS Code: **Arquivo → Abrir pasta** e escolha `toledo-acessivel`
3. Clique com o botão direito em `index.html` → **Open with Live Server**  
   (ou abra `index.html` direto no Chrome/Edge/Firefox)

Não precisa de Node, npm nem build.

## Estrutura

```
toledo-acessivel/
├── index.html              # Início
├── lugares.html            # Lista de lugares
├── lugar.html              # Detalhe de um lugar (?slug=...)
├── roteiro.html            # Roteiro de 3 dias
├── comida.html             # Gastronomia
├── chegada.html            # Como chegar
├── acessibilidade.html     # Guia dos programas
├── css/
│   └── styles.css          # Visual + modos de acessibilidade
├── js/
│   ├── data.js             # Conteúdo (lugares, roteiro, comida)
│   ├── a11y.js             # Programas de acessibilidade
│   └── render.js           # Monta cards e páginas
└── README.md
```

## Programas de acessibilidade

| Perfil | O que faz |
|--------|-----------|
| Autismo | Modo calmo, menos movimento, página simplificada |
| Surdez | Textos visuais + widget VLibras (Libras) |
| Dislexia | Fonte Lexend, espaçamento amplo, régua de leitura |
| Baixa visão | Alto contraste, texto até 200%, links sublinhados |
| Deficiência física | Botões grandes e paleta de comandos |

**Atalhos**

- `Ctrl+K` ou `Ctrl+Shift+P` — paleta de programas (estilo Visual Studio)
- `Tab` / `Enter` / `Esc` — navegação por teclado
- Botão **Ouvir** — leitura em voz alta (pt-BR)
- Botão azul do **VLibras** — tradução para Libras

Preferências ficam salvas no `localStorage` do navegador.

## Subir no GitHub

```bash
cd toledo-acessivel
git init
git add .
git commit -m "Site Toledo Acessível"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/toledo-acessivel.git
git push -u origin main
```

No repositório: **Settings → Pages → Deploy from a branch → main → / (root)**.

O site ficará em `https://SEU_USUARIO.github.io/toledo-acessivel/`.

## Observação

As notas de rampa, banheiro e sensorial são orientações de visita. Confirme sempre no local no dia anterior.
